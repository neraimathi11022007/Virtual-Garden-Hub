export type AuthFormInput = { email: string; password: string; name?: string; accountMode?: boolean };

export function validateAuthForm({ email, password, name = "", accountMode = false }: AuthFormInput): string | null {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return "Enter a valid email address.";
  if (password.length < 8) return "Password must be at least 8 characters.";
  if (accountMode && !name.trim()) return "Enter your name to create an account.";
  return null;
}
