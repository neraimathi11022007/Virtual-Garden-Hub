export const primaryNavigation = [
  { href: "/dashboard", label: "Home" },
  { href: "/garden", label: "3D Garden" },
  { href: "/guide", label: "Plant Guide" },
  { href: "/learning", label: "Learning Hub" },
  { href: "/quiz", label: "Quiz" },
] as const;
