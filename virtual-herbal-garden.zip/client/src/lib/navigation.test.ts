import { describe, expect, it } from "vitest";
import { plants } from "@/data/plants";
import { primaryNavigation } from "./navigation";

describe("primary navigation and plant selection registry", () => {
  it("preserves every primary destination", () => {
    expect(primaryNavigation.map((item) => item.href)).toEqual(["/dashboard", "/garden", "/guide", "/learning", "/quiz"]);
  });

  it("resolves every interactive plant click to the matching information record", () => {
    const expected = ["Tulsi", "Neem", "Aloe Vera", "Turmeric", "Ginger", "Mint", "Lemongrass", "Ashwagandha"];
    expect(plants.map((plant) => plant.name)).toEqual(expected);
    for (const plant of plants) expect(plants.find((candidate) => candidate.id === plant.id)?.name).toBe(plant.name);
  });
});
