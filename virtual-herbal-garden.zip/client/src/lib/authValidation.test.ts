import { describe, expect, it } from "vitest";
import { validateAuthForm } from "./authValidation";

describe("validateAuthForm", () => {
  it("accepts a valid sign-in form", () => {
    expect(validateAuthForm({ email: "garden@example.com", password: "eightword" })).toBeNull();
  });

  it("rejects malformed email and short passwords", () => {
    expect(validateAuthForm({ email: "not-an-email", password: "eightword" })).toBe("Enter a valid email address.");
    expect(validateAuthForm({ email: "garden@example.com", password: "short" })).toBe("Password must be at least 8 characters.");
  });

  it("requires a name for account creation", () => {
    expect(validateAuthForm({ email: "garden@example.com", password: "eightword", accountMode: true })).toBe("Enter your name to create an account.");
  });
});
