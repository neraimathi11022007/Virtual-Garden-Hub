import type { Plant } from "@/data/plants";

export const gardenBounds = { minX: -12, maxX: 12, minZ: -9, maxZ: 9 } as const;

export const viewAngles = [
  [0, 0.8],
  [0, -0.8],
  [0.8, 0],
  [-0.8, 0],
  [0.8, 0.8],
  [-0.8, -0.8],
] as const;

export const gardenObstacles = [
  { x: 7.2, z: -6.2, radius: 2.65, label: "Learning Hub" },
  { x: 8.2, z: 6.5, radius: 1.85, label: "water" },
  { x: -5.8, z: 6.2, radius: 1.45, label: "bench" },
  { x: -7.2, z: -5.4, radius: 1.75, label: "eco structure" },
  { x: -11, z: -7, radius: 1.5, label: "tree" },
  { x: 11, z: -7, radius: 1.5, label: "tree" },
  { x: -11, z: 7, radius: 1.35, label: "tree" },
  { x: 11, z: 7, radius: 1.35, label: "tree" },
  { x: 2, z: 5, radius: 0.82, label: "rock" },
  { x: -3, z: 5, radius: 0.82, label: "rock" },
  { x: 7, z: 2, radius: 0.82, label: "rock" },
  { x: -7, z: 1, radius: 0.82, label: "rock" },
] as const;

export function getPlantViewAnchors(plant: Plant) {
  return viewAngles.map(([dx, dz]) => ({
    x: plant.position[0] + dx,
    z: plant.position[2] + dz,
  }));
}

export function isInsideGarden(x: number, z: number, padding = 0.7) {
  return x >= gardenBounds.minX + padding && x <= gardenBounds.maxX - padding && z >= gardenBounds.minZ + padding && z <= gardenBounds.maxZ - padding;
}

function isObstacleFree(x: number, z: number, clearance = 0.25) {
  return gardenObstacles.every((obstacle) => Math.hypot(x - obstacle.x, z - obstacle.z) > obstacle.radius + clearance);
}

export function isViewPathClear(plant: Plant, anchor: { x: number; z: number }) {
  for (let step = 0.1; step < 1; step += 0.1) {
    const x = anchor.x + (plant.position[0] - anchor.x) * step;
    const z = anchor.z + (plant.position[2] - anchor.z) * step;
    if (!isObstacleFree(x, z, 0.12)) return false;
  }
  return isObstacleFree(anchor.x, anchor.z, 0.12);
}

export function buildPlantVisibilityReport(registry: Plant[]) {
  return registry.map((plant) => {
    const anchors = getPlantViewAnchors(plant);
    return {
      id: plant.id,
      model: plant.model,
      photo: plant.image,
      position: plant.position,
      allViewAnchorsInside: anchors.every(({ x, z }) => isInsideGarden(x, z)),
      allViewPathsClear: anchors.every((anchor) => isViewPathClear(plant, anchor)),
    };
  });
}
