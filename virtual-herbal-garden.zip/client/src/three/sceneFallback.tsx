import React, { type ReactElement } from "react";

export const sceneFallbackContent = {
  title: "Garden view unavailable",
  message: "Your browser could not initialize the 3D scene. Open the Plant Guide to continue learning.",
};

export function SceneFallback(): ReactElement {
  return <div className="scene-fallback" role="status" aria-live="polite"><strong>{sceneFallbackContent.title}</strong><span>{sceneFallbackContent.message}</span></div>;
}
