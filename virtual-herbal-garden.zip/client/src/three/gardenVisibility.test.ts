import { describe, expect, it } from "vitest";
import { plants } from "@/data/plants";
import { buildPlantVisibilityReport } from "./gardenVisibility";

describe("garden visibility registry", () => {
  it("keeps all eight plant identities distinct and media-mapped", () => {
    const report = buildPlantVisibilityReport(plants);
    expect(report).toHaveLength(8);
    expect(new Set(report.map((plant) => plant.id)).size).toBe(8);
    expect(new Set(report.map((plant) => plant.model)).size).toBe(8);
    expect(report.every((plant) => plant.photo.startsWith("/manus-storage/"))).toBe(true);
  });

  it("keeps every plant's six camera anchors inside the walkable garden", () => {
    const report = buildPlantVisibilityReport(plants);
    expect(report.every((plant) => plant.allViewAnchorsInside)).toBe(true);
    expect(report.every((plant) => plant.allViewPathsClear)).toBe(true);
  });

  it("keeps plant beds separated enough for selectable, non-overlapping labels", () => {
    for (let i = 0; i < plants.length; i += 1) {
      for (let j = i + 1; j < plants.length; j += 1) {
        const dx = plants[i].position[0] - plants[j].position[0];
        const dz = plants[i].position[2] - plants[j].position[2];
        expect(Math.hypot(dx, dz)).toBeGreaterThan(1.55);
      }
    }
  });
});
