import { describe, expect, it } from "vitest";
import { SceneFallback, sceneFallbackContent } from "./sceneFallback";

describe("SceneFallback", () => {
  it("returns an accessible live status fallback", () => {
    const element = SceneFallback();
    const props = element.props as { role?: string; "aria-live"?: string };
    expect(props.role).toBe("status");
    expect(props["aria-live"]).toBe("polite");
    expect(sceneFallbackContent.title).toBe("Garden view unavailable");
  });
});
