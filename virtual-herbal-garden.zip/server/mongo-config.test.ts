import { describe, expect, it } from "vitest";
import { getStorageMode } from "./dataStore";

describe("MongoDB configuration fallback", () => {
  it("uses memory fallback when MONGODB_URI is not configured", () => {
    const previous = process.env.MONGODB_URI;
    delete process.env.MONGODB_URI;
    expect(getStorageMode()).toBe("memory-fallback");
    if (previous) process.env.MONGODB_URI = previous;
  });
});
