import { describe, expect, it } from "vitest";
import { listLessons, listPlants, listQuizQuestions, saveQuizResult } from "./dataStore";

describe("herbal learning data API helpers", () => {
  it("provides the required educational collections in fallback mode", async () => {
    delete process.env.MONGODB_URI;
    expect((await listPlants()).length).toBe(8);
    expect((await listLessons()).length).toBe(6);
    expect((await listQuizQuestions()).length).toBeGreaterThanOrEqual(10);
  });

  it("creates a dated quiz result record without a database", async () => {
    delete process.env.MONGODB_URI;
    const result = await saveQuizResult({ userId: "guest", score: 8, totalQuestions: 11 });
    expect(result.score).toBe(8);
    expect(result.totalQuestions).toBe(11);
    expect(result.date).toBeInstanceOf(Date);
  });
});
