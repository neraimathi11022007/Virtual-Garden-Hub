import { Router } from "express";
import crypto from "node:crypto";
import { listLessons, listPlants, listQuizQuestions, registerUser, saveQuizResult } from "./dataStore";

const router = Router();
const fallbackUsers = new Map<string, { name: string; email: string; passwordHash: string }>();
const sessions = new Map<string, { email: string; createdAt: number }>();
const hashPassword = (password: string) => crypto.scryptSync(password, "virtual-herbal-garden-salt", 32).toString("hex");

router.get("/health", (_req, res) => res.json({ ok: true, storage: process.env.MONGODB_URI ? "mongodb" : "memory-fallback" }));
router.get("/plants", async (_req, res) => { try { res.json({ data: await listPlants() }); } catch { res.status(503).json({ data: [], message: "Plant data is temporarily unavailable. The interactive garden remains available." }); } });
router.get("/lessons", async (_req, res) => { try { res.json({ data: await listLessons() }); } catch { res.status(503).json({ data: [], message: "Learning modules are temporarily unavailable." }); } });
router.get("/quiz/questions", async (_req, res) => { try { res.json({ data: await listQuizQuestions() }); } catch { res.status(503).json({ data: [], message: "Quiz questions are temporarily unavailable." }); } });
router.post("/users/register", async (req, res) => { const { name, email, password } = req.body ?? {}; if (!name || !email || typeof password !== "string" || password.length < 8) return res.status(400).json({ message: "Please provide a name, email, and password with at least 8 characters." }); try { const passwordHash = hashPassword(password); fallbackUsers.set(email.toLowerCase(), { name, email: email.toLowerCase(), passwordHash }); const user = await registerUser({ name, email: email.toLowerCase(), passwordHash }); const token = crypto.randomBytes(24).toString("hex"); sessions.set(token, { email: email.toLowerCase(), createdAt: Date.now() }); return res.status(201).json({ data: user, token }); } catch (error) { return res.status(409).json({ message: error instanceof Error ? error.message : "Unable to create account." }); } });
router.get("/users/me", (req, res) => { const token = String(req.headers.authorization || "").replace(/^Bearer /, ""); const session = sessions.get(token); const user = session ? fallbackUsers.get(session.email) : undefined; if (!user) return res.status(401).json({ message: "Your session has expired. Please sign in again." }); return res.json({ data: { name: user.name, email: user.email } }); });
router.post("/users/login", (req, res) => { const { email, password } = req.body ?? {}; const user = fallbackUsers.get(String(email ?? "").toLowerCase()); if (!user || !password || hashPassword(password) !== user.passwordHash) return res.status(401).json({ message: "Invalid email or password. You can continue as a guest from the welcome page." }); const token = crypto.randomBytes(24).toString("hex"); sessions.set(token, { email: user.email, createdAt: Date.now() }); return res.json({ data: { name: user.name, email: user.email }, token }); });
router.post("/quiz/results", async (req, res) => { const { userId, score, totalQuestions } = req.body ?? {}; if (!Number.isFinite(score) || !Number.isFinite(totalQuestions)) return res.status(400).json({ message: "A numeric score and total question count are required." }); try { res.status(201).json({ data: await saveQuizResult({ userId, score, totalQuestions }) }); } catch { res.status(503).json({ message: "Your result could not be saved, but your score is still shown locally." }); } });
export default router;
