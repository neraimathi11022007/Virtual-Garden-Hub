import { MongoClient, type Db } from "mongodb";
import { lessons, plants, quizQuestions } from "../client/src/data/plants";

export type StorageMode = "mongodb" | "memory-fallback";
let client: MongoClient | null = null;
let db: Db | null = null;

export function getStorageMode(): StorageMode { return process.env.MONGODB_URI ? "mongodb" : "memory-fallback"; }
export async function getMongoDb(): Promise<Db | null> { if (!process.env.MONGODB_URI) return null; if (db) return db; try { client = new MongoClient(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 1200 }); await client.connect(); db = client.db(); return db; } catch (error) { console.warn("[MongoDB] unavailable, using memory fallback", error); return null; } }
export async function listPlants() { const mongo = await getMongoDb(); return mongo ? mongo.collection("plants").find({}).toArray() : plants; }
export async function listLessons() { const mongo = await getMongoDb(); return mongo ? mongo.collection("lessons").find({}).toArray() : lessons; }
export async function listQuizQuestions() { const mongo = await getMongoDb(); return mongo ? mongo.collection("quizQuestions").find({}).toArray() : quizQuestions; }
export async function saveQuizResult(result: { userId?: string; score: number; totalQuestions: number }) { const record = { ...result, date: new Date() }; const mongo = await getMongoDb(); if (mongo) await mongo.collection("quizResults").insertOne(record); return record; }
export async function registerUser(user: { name: string; email: string; passwordHash: string }) { const record = { ...user, createdAt: new Date() }; const mongo = await getMongoDb(); if (mongo) { const existing = await mongo.collection("users").findOne({ email: user.email }); if (existing) throw new Error("Account already exists"); await mongo.collection("users").insertOne(record); } return { name: record.name, email: record.email, createdAt: record.createdAt }; }
